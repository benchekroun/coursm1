#ifndef SCENE_H
#define SCENE_H

void chargerTextures();
void chargerObj();
void dessinerScene();

#endif //SCENE_H
